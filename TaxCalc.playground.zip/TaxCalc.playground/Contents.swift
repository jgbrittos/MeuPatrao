import Foundation

let mediaDeDiasUteisEmUmAno = 252

extension Int {
    var reais: Int { return self }
    var dia: Int { return self }
    var dias: Int { return self }
    var ano: Int { return mediaDeDiasUteisEmUmAno }
    var anos: Int { return self * ano }
    
}
extension Double {
    var reais: Double { return self }
    var porCento: Double { return self / 100.0 }
    var emPorcentagem: Double { return self * 100.0 }
    var formatada: String {
        return String(format: "%g", self)
    }
    func da(_ taxa: Double) -> Double {
        return self * taxa
    }
}

extension String {
    var aoAno: String {
        return self + "% a.a"
    }
}

enum Taxa {
    case CDI
    case IPCA
    case IGP_M
}

class MeuPatrao {
    let POTENCIA: Double = 1 / Double(1.ano)
    //var IPCA: Double = 3.78.porCento fazer melhorias depois
    
    var montanteInicial: Double = 1000.0
    var CDI: Double = 6.4.porCento
    var periodo: Int = 1.ano
    var total: Double = 1000.0
    var rentabilidade: Double = 100.porCento
    var rentabilidadeDiaria: Double = 0.0
    var taxa: Taxa = .CDI
    var taxasNoPeriodo: [Double] = []
    
    var taxaMediaNoPeriodo: String {
        let tmnp = taxasNoPeriodo.reduce(0, +) / Double(periodo)
        return tmnp.emPorcentagem.formatada
    }
    
    func vamosUsarATaxa(_ t: Taxa) {
        taxa = t
    }
    
    func considereUmMontanteInicial(de valor: Double) -> Self {
        montanteInicial = valor
        total = valor
        return self
    }
    
    func considereUmPeriodo(de tempo: Int) -> Self {
        periodo = tempo
        return self
    }
    
    func considereUmaRentabilidadeAtreladaAoCDI(de r: Double)  -> Self {
        rentabilidade = r
        return self
    }
    
    func considereCDINoPeriodo(fixoEm valor: Double)  -> Self {
        CDI = valor
        taxasNoPeriodo = Array(repeating: valor, count: periodo)
        return self
    }
    
    func considereCDI(de valor: Double)  -> Self {
        CDI = valor
        return self
    }
    
    func eMeMostraOsResultados() -> Self {
        print("## ------------ Só confirmando os valores mesmo... ------------ ##\n")
        print("\t\t\t\t      Período: \(periodo) dias\n")
        print("\t\t\t\t  Lucro líquido: R$", String(format: "%.2f", total - montanteInicial), "\n")
        print("\t\t\t\t Montante final: R$", String(format: "%.2f", total), "\n")
        print("\t\t\t\tMontante inicial: R$", String(format: "%.2f", montanteInicial), "\n")
        print("## --------------- Acho que tá tudo Ok mesmo... --------------- ##\n\n\n\n")
        return self
    }
    
    func eQueroSaberAsTaxasTambem() -> Self {
        print("\t\t\t\t\t\t__Taxas__\n")
        print("##        Toma essas porra (seu exigente do caralho...)         ##\n")
        print("##    [até parece que sabe de alguma coisa...estrupício...]     ##\n")
        print("\t\t\t\tRentabilidade bruta: \(rentabilidade.emPorcentagem.formatada.aoAno)\n")
        print("\t\t\t   Taxa média no período: \(taxaMediaNoPeriodo.aoAno)\n")
        print("\t\t\t Rentabilidade diária: \((rentabilidadeDiaria - 1).emPorcentagem.formatada.aoAno)\n")
        print("## Agora sim!? Obrigado. Até semana que vem... #partiu  #sextou ##\n")
        return self
    }
    
    func eFaleAVerdadeAoFimDeTudo() {
        print("\n\n\n\n\n\n\n\n\n")
        print("(.)(.) pq com peitos sempre fica melhor...\n")
        print("e não se esqueça...\n")
        print("a máfia está sempre de olho...")
        print("(-.(-.(-.(-.(-.(-.(-.(-.(-.(-.(-.-).-).-).-).-).-).-).-).-).-).-)\n")
    }
    
    func agoraDaTeusPulo() -> Self {
        /// Fórmula da rentabilidade
        /// Montante inicial * [∏ (1 + taxa) ˆ (1/252)]
        /// Onde 252 é quantidade média de dias úteis em um ano
        /// e a taxa é a taxa a qual o investimento está submetido, i.e: 100% do CDI = 6,4%
        for dia in 0..<periodo {
            let taxaNoDia = taxasNoPeriodo[dia]
            
            rentabilidadeDiaria = pow(1 + rentabilidade.da(taxaNoDia), POTENCIA)
            
            total *= rentabilidadeDiaria
        }
        
        return self
    }
}

MeuPatrao()
    .considereUmMontanteInicial(de: 10000.reais)
    .considereUmPeriodo(de: 2.anos - 4.dias)
    .considereCDINoPeriodo(fixoEm: 6.4.porCento)
    .considereUmaRentabilidadeAtreladaAoCDI(de: 98.porCento)
    .agoraDaTeusPulo()
    .eMeMostraOsResultados()
    .eQueroSaberAsTaxasTambem()
    .eFaleAVerdadeAoFimDeTudo()
